function showAlert(message, redirect = null) {
    alert(message);
    if (redirect) {
        window.location.href = redirect;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    let registerForm = document.querySelector("#registerForm");

    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            let password = document.querySelector("#reg-password").value;
            let confirmPassword = document.querySelector("#reg-confirm-password").value;
            let email = document.querySelector("input[name='email']").value;

            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailPattern.test(email)) {
                showAlert("Invalid email format!", "register.html");
                event.preventDefault();
                return;
            }

            if (password !== confirmPassword) {
                showAlert("Passwords do not match!", "register.html");
                event.preventDefault();
                return;
            }

            if (password.length < 6) {
                showAlert("Password must be at least 6 characters long!", "register.html");
                event.preventDefault();
            }
        });
    }
});